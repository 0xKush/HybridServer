package es.uvigo.esei.dai.hybridserver.controller;

public interface ControllerFactory {
    HTMLController createHtmlController();
}
